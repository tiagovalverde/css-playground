# Merge Conflict

See [documentation](https://code.visualstudio.com/docs/editor/versioncontrol#_merge-conflicts).

**Notice** This is a an extension that is bundled with Visual Studio Code.
